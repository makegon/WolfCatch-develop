(function() {

  var CatchTheEgg = new GameManager();

})();
